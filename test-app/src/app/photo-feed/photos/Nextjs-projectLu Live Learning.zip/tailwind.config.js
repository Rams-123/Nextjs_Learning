/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        "background-color-primary": "#fff",
        "text-primary": "#000",
        "color-neutral-neutral-lighter": "#ccc",
      },
      spacing: {},
      fontFamily: {
        "heading-mobile-h4": "Roboto",
      },
      borderRadius: {
        "31xl": "50px",
      },
    },
    fontSize: {
      sm: "14px",
      base: "16px",
      "5xl": "24px",
      "17xl": "36px",
      xl: "20px",
      lg: "18px",
      "13xl": "32px",
      "29xl": "48px",
      "21xl": "40px",
      inherit: "inherit",
    },
  },
  corePlugins: {
    preflight: false,
  },
};
