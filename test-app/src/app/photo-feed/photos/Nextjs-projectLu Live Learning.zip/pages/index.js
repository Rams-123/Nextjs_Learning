const LiveLearningPrograms = () => {
  return (
    <div className="w-full relative h-[8749.7px] text-left text-base text-text-primary font-heading-mobile-h4">
      <div className="absolute top-[0px] left-[0px] overflow-hidden flex flex-col items-start justify-start">
        <div className="w-[1440px] bg-background-color-primary flex flex-col items-center justify-start">
          <div className="self-stretch box-border h-[72px] overflow-hidden shrink-0 flex flex-row items-center justify-between py-0 px-16 border-b-[1px] border-solid border-text-primary">
            <div className="flex flex-row items-center justify-start">
              <img
                className="w-[63px] relative h-[27px] overflow-hidden shrink-0"
                alt=""
                src="/color--dark.svg"
              />
            </div>
            <div className="flex flex-row items-center justify-center gap-[16px]">
              <div className="overflow-hidden flex flex-row items-start justify-start gap-[32px]">
                <div className="relative leading-[150%]">Live Learning</div>
                <div className="relative leading-[150%]">Bite Sized</div>
                <div className="relative leading-[150%]">Recorded</div>
                <div className="flex flex-row items-center justify-center gap-[4px]">
                  <div className="relative leading-[150%]">LU.ai</div>
                  <img
                    className="w-6 relative h-6 overflow-hidden shrink-0"
                    alt=""
                    src="/chevron-down.svg"
                  />
                </div>
              </div>
              <div className="flex flex-row items-start justify-start gap-[16px]">
                <div className="flex flex-row items-center justify-center py-2 px-5 border-[1px] border-solid border-text-primary">
                  <div className="relative leading-[150%]">Join</div>
                </div>
                <div className="bg-text-primary flex flex-row items-center justify-center py-2 px-5 text-background-color-primary border-[1px] border-solid border-text-primary">
                  <div className="relative leading-[150%]">Sign Up</div>
                </div>
              </div>
            </div>
          </div>
          <div className="self-stretch relative bg-background-color-primary h-px">
            <div className="absolute top-[-17px] left-[918px] bg-background-color-primary overflow-hidden flex flex-col items-start justify-start p-6 gap-[16px] border-[1px] border-solid border-text-primary">
              <div className="w-80 flex flex-row items-start justify-start py-2 px-0 box-border gap-[12px]">
                <img
                  className="w-6 relative h-6 overflow-hidden shrink-0"
                  alt=""
                  src="/icon--relume.svg"
                />
                <div className="flex-1 flex flex-col items-start justify-start">
                  <div className="self-stretch relative leading-[150%] font-semibold">
                    Page One
                  </div>
                  <div className="self-stretch relative text-sm leading-[150%]">
                    Learn at your own pace, anytime, anywhere
                  </div>
                </div>
              </div>
              <div className="w-80 flex flex-row items-start justify-start py-2 px-0 box-border gap-[12px]">
                <img
                  className="w-6 relative h-6 overflow-hidden shrink-0"
                  alt=""
                  src="/icon--relume.svg"
                />
                <div className="flex-1 flex flex-col items-start justify-start">
                  <div className="self-stretch relative leading-[150%] font-semibold">
                    Page Two
                  </div>
                  <div className="self-stretch relative text-sm leading-[150%]">
                    Connect with industry leaders and experts
                  </div>
                </div>
              </div>
              <div className="w-80 flex flex-row items-start justify-start py-2 px-0 box-border gap-[12px]">
                <img
                  className="w-6 relative h-6 overflow-hidden shrink-0"
                  alt=""
                  src="/icon--relume.svg"
                />
                <div className="flex-1 flex flex-col items-start justify-start">
                  <div className="self-stretch relative leading-[150%] font-semibold">
                    Page Three
                  </div>
                  <div className="self-stretch relative text-sm leading-[150%]">
                    Earn LU Coins and unlock exclusive rewards
                  </div>
                </div>
              </div>
              <div className="w-80 flex flex-row items-start justify-start py-2 px-0 box-border gap-[12px]">
                <img
                  className="w-6 relative h-6 overflow-hidden shrink-0"
                  alt=""
                  src="/icon--relume.svg"
                />
                <div className="flex-1 flex flex-col items-start justify-start">
                  <div className="self-stretch relative leading-[150%] font-semibold">
                    Page Four
                  </div>
                  <div className="self-stretch relative text-sm leading-[150%]">
                    Stay updated with the latest industry trends
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="w-[1440px] flex flex-col items-start justify-start py-28 px-16 box-border bg-[url('/layout--467@3x.png')] bg-cover bg-no-repeat bg-[top] text-background-color-primary">
          <div className="self-stretch flex flex-row items-start justify-start gap-[80px]">
            <div className="self-stretch flex-1 flex flex-col items-start justify-start">
              <div className="self-stretch flex flex-col items-start justify-start gap-[16px]">
                <div className="self-stretch flex flex-col items-start justify-start gap-[16px]">
                  <div className="self-stretch relative leading-[150%] font-semibold">
                    Engage
                  </div>
                  <div className="self-stretch flex flex-col items-start justify-start gap-[24px] text-29xl">
                    <b className="self-stretch relative leading-[120%]">
                      Interactive Live Learning Programs: Learn, Collaborate,
                      Grow
                    </b>
                    <div className="self-stretch relative text-lg leading-[150%]">
                      Experience real-time engagement with our interactive Live
                      Learning Programs. Join our community of learners and
                      enhance your skills in a collaborative environment.
                    </div>
                  </div>
                </div>
                <div className="flex flex-row items-center justify-start pt-4 px-0 pb-0 gap-[24px]">
                  <div className="flex flex-row items-center justify-center py-3 px-6 border-[1px] border-solid border-background-color-primary">
                    <div className="relative leading-[150%]">Learn More</div>
                  </div>
                  <div className="flex flex-row items-center justify-center gap-[8px]">
                    <div className="relative leading-[150%]">Sign Up</div>
                    <img
                      className="w-6 relative h-6 overflow-hidden shrink-0"
                      alt=""
                      src="/icon--chevronright.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="flex-1 flex flex-col items-start justify-end pt-[400px] px-0 pb-0 text-xl">
              <div className="self-stretch flex flex-col items-start justify-end py-0 px-[46px]">
                <div className="self-stretch flex flex-row items-start justify-start gap-[24px]">
                  <div className="flex-1 flex flex-col items-start justify-start gap-[16px]">
                    <b className="self-stretch relative leading-[140%]">
                      Learn Together
                    </b>
                    <div className="self-stretch relative text-base leading-[150%]">
                      Connect with industry experts and fellow learners in our
                      live sessions.
                    </div>
                  </div>
                  <div className="flex-1 flex flex-col items-start justify-start gap-[16px]">
                    <b className="self-stretch relative leading-[140%]">
                      Expand Skills
                    </b>
                    <div className="self-stretch relative text-base leading-[150%]">
                      Unlock new opportunities and advance your career with our
                      Live Learning Programs.
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="w-[1440px] bg-background-color-primary overflow-hidden flex flex-col items-center justify-start py-28 px-16 box-border gap-[80px] text-center text-21xl">
          <b className="w-[768px] relative leading-[120%] inline-block">
            Refer and Earn
          </b>
          <div className="self-stretch flex flex-row items-start justify-center gap-[48px] text-5xl">
            <div className="flex-1 flex flex-col items-center justify-start gap-[24px]">
              <div className="self-stretch flex flex-col items-center justify-start gap-[24px]">
                <img
                  className="w-12 relative h-12 overflow-hidden shrink-0"
                  alt=""
                  src="/icon--relume1.svg"
                />
                <div className="self-stretch flex flex-col items-start justify-start gap-[24px]">
                  <b className="self-stretch relative leading-[140%]">
                    Long heading is what you see here in this feature section
                  </b>
                  <div className="self-stretch relative text-base leading-[150%]">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Suspendisse varius enim in eros elementum tristique. Duis
                    cursus, mi quis viverra ornare, eros dolor interdum nulla.
                  </div>
                </div>
              </div>
              <div className="self-stretch flex flex-col items-center justify-start pt-2 px-0 pb-0 text-left text-base">
                <div className="flex flex-row items-center justify-center gap-[8px]">
                  <div className="relative leading-[150%]">Button</div>
                  <img
                    className="w-6 relative h-6 overflow-hidden shrink-0"
                    alt=""
                    src="/icon--chevronright1.svg"
                  />
                </div>
              </div>
            </div>
            <div className="flex-1 flex flex-col items-center justify-start gap-[24px]">
              <div className="self-stretch flex flex-col items-center justify-start gap-[24px]">
                <img
                  className="w-12 relative h-12 overflow-hidden shrink-0"
                  alt=""
                  src="/icon--relume2.svg"
                />
                <div className="self-stretch flex flex-col items-start justify-start gap-[24px]">
                  <b className="self-stretch relative leading-[140%]">
                    Long heading is what you see here in this feature section
                  </b>
                  <div className="self-stretch relative text-base leading-[150%]">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Suspendisse varius enim in eros elementum tristique. Duis
                    cursus, mi quis viverra ornare, eros dolor interdum nulla.
                  </div>
                </div>
              </div>
              <div className="self-stretch flex flex-col items-center justify-start pt-2 px-0 pb-0 text-left text-base">
                <div className="flex flex-row items-center justify-center gap-[8px]">
                  <div className="relative leading-[150%]">Button</div>
                  <img
                    className="w-6 relative h-6 overflow-hidden shrink-0"
                    alt=""
                    src="/icon--chevronright.svg"
                  />
                </div>
              </div>
            </div>
            <div className="flex-1 flex flex-col items-center justify-start gap-[24px]">
              <div className="self-stretch flex flex-col items-center justify-start gap-[24px]">
                <img
                  className="w-12 relative h-12 overflow-hidden shrink-0"
                  alt=""
                  src="/icon--relume3.svg"
                />
                <div className="self-stretch flex flex-col items-start justify-start gap-[24px]">
                  <b className="self-stretch relative leading-[140%]">
                    Long heading is what you see here in this feature section
                  </b>
                  <div className="self-stretch relative text-base leading-[150%]">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Suspendisse varius enim in eros elementum tristique. Duis
                    cursus, mi quis viverra ornare, eros dolor interdum nulla.
                  </div>
                </div>
              </div>
              <div className="self-stretch flex flex-col items-center justify-start pt-2 px-0 pb-0 text-left text-base">
                <div className="flex flex-row items-center justify-center gap-[8px]">
                  <div className="relative leading-[150%]">Button</div>
                  <img
                    className="w-6 relative h-6 overflow-hidden shrink-0"
                    alt=""
                    src="/icon--chevronright2.svg"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="w-[1440px] bg-background-color-primary overflow-hidden flex flex-col items-center justify-start py-28 px-16 box-border gap-[80px] text-center">
          <div className="w-[768px] flex flex-col items-center justify-start gap-[16px]">
            <div className="relative leading-[150%] font-semibold">
              Articles
            </div>
            <div className="self-stretch flex flex-col items-center justify-start gap-[24px] text-29xl">
              <b className="self-stretch relative leading-[120%]">
                Explore Our Programs
              </b>
              <div className="self-stretch relative text-lg leading-[150%]">
                Discover our live learning programs by subject or skill level.
              </div>
            </div>
          </div>
          <div className="self-stretch flex flex-col items-center justify-start gap-[64px] text-left text-sm">
            <div className="self-stretch flex flex-row items-start justify-start gap-[32px]">
              <div className="flex-1 flex flex-col items-start justify-start border-[1px] border-solid border-text-primary">
                <img
                  className="self-stretch relative max-w-full overflow-hidden h-[300px] shrink-0 object-cover"
                  alt=""
                  src="/placeholder-image@2x.png"
                />
                <div className="self-stretch flex flex-col items-start justify-start p-6 gap-[24px]">
                  <div className="self-stretch flex flex-col items-start justify-start gap-[8px]">
                    <div className="self-stretch relative leading-[150%] font-semibold">
                      All
                    </div>
                    <b className="self-stretch relative text-5xl leading-[140%]">
                      The Power of Coding
                    </b>
                    <div className="self-stretch relative text-base leading-[150%]">
                      Learn coding from industry experts and unlock new
                      opportunities.
                    </div>
                  </div>
                  <div className="self-stretch flex flex-row items-center justify-start gap-[16px]">
                    <img
                      className="w-12 relative h-12 object-cover"
                      alt=""
                      src="/placeholder-image@2x.png"
                    />
                    <div className="flex-1 flex flex-col items-start justify-start">
                      <div className="self-stretch relative leading-[150%] font-semibold">
                        John Doe
                      </div>
                      <div className="self-stretch flex flex-row items-center justify-start gap-[8px]">
                        <div className="relative leading-[150%]">
                          11 Jan 2022
                        </div>
                        <div className="relative text-lg leading-[150%]">•</div>
                        <div className="relative leading-[150%]">
                          5 min read
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex-1 flex flex-col items-start justify-start border-[1px] border-solid border-text-primary">
                <img
                  className="self-stretch relative max-w-full overflow-hidden h-[300px] shrink-0 object-cover"
                  alt=""
                  src="/placeholder-image@2x.png"
                />
                <div className="self-stretch flex flex-col items-start justify-start p-6 gap-[24px]">
                  <div className="self-stretch flex flex-col items-start justify-start gap-[8px]">
                    <div className="self-stretch relative leading-[150%] font-semibold">
                      Coding
                    </div>
                    <b className="self-stretch relative text-5xl leading-[140%]">
                      The Future of AI
                    </b>
                    <div className="self-stretch relative text-base leading-[150%]">
                      Explore the world of artificial intelligence and its
                      applications.
                    </div>
                  </div>
                  <div className="self-stretch flex flex-row items-center justify-start gap-[16px]">
                    <img
                      className="w-12 relative h-12 object-cover"
                      alt=""
                      src="/placeholder-image@2x.png"
                    />
                    <div className="flex-1 flex flex-col items-start justify-start">
                      <div className="self-stretch relative leading-[150%] font-semibold">
                        Jane Smith
                      </div>
                      <div className="self-stretch flex flex-row items-center justify-start gap-[8px]">
                        <div className="relative leading-[150%]">
                          11 Jan 2022
                        </div>
                        <div className="relative text-lg leading-[150%]">•</div>
                        <div className="relative leading-[150%]">
                          7 min read
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex-1 flex flex-col items-start justify-start border-[1px] border-solid border-text-primary">
                <img
                  className="self-stretch relative max-w-full overflow-hidden h-[300px] shrink-0 object-cover"
                  alt=""
                  src="/placeholder-image@2x.png"
                />
                <div className="self-stretch flex flex-col items-start justify-start p-6 gap-[24px]">
                  <div className="self-stretch flex flex-col items-start justify-start gap-[8px]">
                    <div className="self-stretch relative leading-[150%] font-semibold">
                      AI
                    </div>
                    <b className="self-stretch relative text-5xl leading-[140%]">
                      Master Data Analytics
                    </b>
                    <div className="self-stretch relative text-base leading-[150%]">
                      Gain insights from data and make informed business
                      decisions.
                    </div>
                  </div>
                  <div className="self-stretch flex flex-row items-center justify-start gap-[16px]">
                    <img
                      className="w-12 relative h-12 object-cover"
                      alt=""
                      src="/placeholder-image@2x.png"
                    />
                    <div className="flex-1 flex flex-col items-start justify-start">
                      <div className="self-stretch relative leading-[150%] font-semibold">
                        David Johnson
                      </div>
                      <div className="self-stretch flex flex-row items-center justify-start gap-[8px]">
                        <div className="relative leading-[150%]">
                          11 Jan 2022
                        </div>
                        <div className="relative text-lg leading-[150%]">•</div>
                        <div className="relative leading-[150%]">
                          6 min read
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="w-[106px] box-border flex flex-row items-center justify-center py-3 px-6 text-base border-[1px] border-solid border-text-primary">
              <div className="relative leading-[150%]">View All</div>
            </div>
          </div>
        </div>
        <div className="w-[1440px] bg-background-color-primary flex flex-col items-center justify-start py-28 px-16 box-border gap-[80px]">
          <div className="self-stretch flex flex-row items-end justify-between">
            <div className="w-[768px] flex flex-col items-start justify-start gap-[16px]">
              <div className="relative leading-[150%] font-semibold">
                Tagline
              </div>
              <div className="self-stretch flex flex-col items-center justify-start gap-[16px] text-29xl">
                <b className="self-stretch relative leading-[120%]">Products</b>
                <div className="self-stretch relative text-lg leading-[150%]">{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</div>
              </div>
            </div>
            <div className="w-[106px] box-border flex flex-row items-center justify-center py-3 px-6 border-[1px] border-solid border-text-primary">
              <div className="relative leading-[150%]">View all</div>
            </div>
          </div>
          <div className="flex flex-col items-start justify-start gap-[48px] text-lg">
            <div className="w-[1312px] flex flex-col items-start justify-start">
              <div className="self-stretch flex flex-row items-start justify-start gap-[32px]">
                <div className="flex flex-col items-start justify-start gap-[16px]">
                  <img
                    className="w-[304px] relative h-[364.8px] object-cover"
                    alt=""
                    src="/placeholder-image@2x.png"
                  />
                  <div className="self-stretch flex flex-row items-start justify-start gap-[16px]">
                    <div className="flex-1 flex flex-col items-start justify-start">
                      <div className="w-[304px] relative leading-[150%] font-semibold inline-block">
                        Product name
                      </div>
                      <div className="self-stretch relative text-sm leading-[150%]">
                        Variant
                      </div>
                    </div>
                    <div className="relative text-xl leading-[150%] font-semibold">
                      $55
                    </div>
                  </div>
                  <div className="self-stretch flex flex-row items-center justify-center py-2 px-5 text-base border-[1px] border-solid border-text-primary">
                    <div className="relative leading-[150%]">Add to cart</div>
                  </div>
                </div>
                <div className="flex flex-col items-start justify-start gap-[16px]">
                  <img
                    className="w-[304px] relative h-[364.8px] object-cover"
                    alt=""
                    src="/placeholder-image@2x.png"
                  />
                  <div className="self-stretch flex flex-row items-start justify-start gap-[16px]">
                    <div className="flex-1 flex flex-col items-start justify-start">
                      <div className="self-stretch relative leading-[150%] font-semibold">
                        Product name
                      </div>
                      <div className="self-stretch relative text-sm leading-[150%]">
                        Variant
                      </div>
                    </div>
                    <div className="relative text-xl leading-[150%] font-semibold">
                      $55
                    </div>
                  </div>
                  <div className="self-stretch flex flex-row items-center justify-center py-2 px-5 text-base border-[1px] border-solid border-text-primary">
                    <div className="relative leading-[150%]">Add to cart</div>
                  </div>
                </div>
                <div className="flex flex-col items-start justify-start gap-[16px]">
                  <img
                    className="w-[304px] relative h-[364.8px] object-cover"
                    alt=""
                    src="/placeholder-image@2x.png"
                  />
                  <div className="self-stretch flex flex-row items-start justify-start gap-[16px]">
                    <div className="flex-1 flex flex-col items-start justify-start">
                      <div className="self-stretch relative leading-[150%] font-semibold">
                        Product name
                      </div>
                      <div className="self-stretch relative text-sm leading-[150%]">
                        Variant
                      </div>
                    </div>
                    <div className="relative text-xl leading-[150%] font-semibold">
                      $55
                    </div>
                  </div>
                  <div className="self-stretch flex flex-row items-center justify-center py-2 px-5 text-base border-[1px] border-solid border-text-primary">
                    <div className="relative leading-[150%]">Add to cart</div>
                  </div>
                </div>
                <div className="flex flex-col items-start justify-start gap-[16px]">
                  <img
                    className="w-[304px] relative h-[364.8px] object-cover"
                    alt=""
                    src="/placeholder-image@2x.png"
                  />
                  <div className="self-stretch flex flex-row items-start justify-start gap-[16px]">
                    <div className="flex-1 flex flex-col items-start justify-start">
                      <div className="self-stretch relative leading-[150%] font-semibold">
                        Product name
                      </div>
                      <div className="self-stretch relative text-sm leading-[150%]">
                        Variant
                      </div>
                    </div>
                    <div className="relative text-xl leading-[150%] font-semibold">
                      $55
                    </div>
                  </div>
                  <div className="self-stretch flex flex-row items-center justify-center py-2 px-5 text-base border-[1px] border-solid border-text-primary">
                    <div className="relative leading-[150%]">Add to cart</div>
                  </div>
                </div>
                <div className="flex flex-col items-start justify-start gap-[16px]">
                  <img
                    className="w-[304px] relative h-[364.8px] object-cover"
                    alt=""
                    src="/placeholder-image@2x.png"
                  />
                  <div className="self-stretch flex flex-row items-start justify-start gap-[16px]">
                    <div className="flex-1 flex flex-col items-start justify-start">
                      <div className="self-stretch relative leading-[150%] font-semibold">
                        Product name
                      </div>
                      <div className="self-stretch relative text-sm leading-[150%]">
                        Variant
                      </div>
                    </div>
                    <div className="relative text-xl leading-[150%] font-semibold">
                      $55
                    </div>
                  </div>
                  <div className="self-stretch flex flex-row items-center justify-center py-2 px-5 text-base border-[1px] border-solid border-text-primary">
                    <div className="relative leading-[150%]">Add to cart</div>
                  </div>
                </div>
              </div>
            </div>
            <div className="w-[1312px] flex flex-row items-center justify-between">
              <div className="flex flex-row items-start justify-start gap-[8px]">
                <div className="w-2 relative rounded-[50%] bg-text-primary h-2" />
                <div className="w-2 relative rounded-[50%] bg-color-neutral-neutral-lighter h-2" />
                <div className="w-2 relative rounded-[50%] bg-color-neutral-neutral-lighter h-2" />
                <div className="w-2 relative rounded-[50%] bg-color-neutral-neutral-lighter h-2" />
                <div className="w-2 relative rounded-[50%] bg-color-neutral-neutral-lighter h-2" />
              </div>
              <div className="flex flex-row items-start justify-start gap-[15px]">
                <div className="rounded-31xl flex flex-row items-center justify-center p-3 border-[1px] border-solid border-text-primary">
                  <img
                    className="w-6 relative h-6 overflow-hidden shrink-0"
                    alt=""
                    src="/icon.svg"
                  />
                </div>
                <div className="rounded-31xl flex flex-row items-center justify-center p-3 border-[1px] border-solid border-text-primary">
                  <img
                    className="w-6 relative h-6 overflow-hidden shrink-0"
                    alt=""
                    src="/icon1.svg"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="w-[1440px] bg-background-color-primary overflow-hidden flex flex-col items-center justify-start py-28 px-16 box-border gap-[80px] text-center text-29xl">
          <div className="w-[560px] flex flex-col items-center justify-start gap-[24px]">
            <b className="self-stretch relative leading-[120%]">
              Customer testimonials
            </b>
            <div className="self-stretch relative text-lg leading-[150%]">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            </div>
          </div>
          <div className="self-stretch flex flex-row items-start justify-start gap-[32px] text-left text-lg">
            <div className="flex-1 overflow-hidden flex flex-col items-start justify-start p-8 gap-[32px] border-[1px] border-solid border-text-primary">
              <div className="flex flex-col items-start justify-start gap-[32px]">
                <div className="overflow-hidden flex flex-row items-start justify-start gap-[4px]">
                  <img
                    className="w-5 relative h-[18.9px]"
                    alt=""
                    src="/vector.svg"
                  />
                  <img
                    className="w-5 relative h-[18.9px]"
                    alt=""
                    src="/vector.svg"
                  />
                  <img
                    className="w-5 relative h-[18.9px]"
                    alt=""
                    src="/vector.svg"
                  />
                  <img
                    className="w-5 relative h-[18.9px]"
                    alt=""
                    src="/vector.svg"
                  />
                  <img
                    className="w-5 relative h-[18.9px]"
                    alt=""
                    src="/vector.svg"
                  />
                </div>
                <div className="w-[352px] relative leading-[150%] inline-block">
                  "Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Suspendisse varius enim in eros elementum tristique. Duis
                  cursus, mi quis viverra ornare."
                </div>
              </div>
              <div className="flex flex-row items-center justify-start gap-[16px] text-base">
                <img
                  className="w-14 relative rounded-[50%] h-14 object-cover"
                  alt=""
                  src="/avatar-image@2x.png"
                />
                <div className="flex flex-col items-start justify-start">
                  <div className="relative leading-[150%] font-semibold">
                    Name Surname
                  </div>
                  <div className="relative leading-[150%]">
                    Position, Company name
                  </div>
                </div>
              </div>
            </div>
            <div className="flex-1 overflow-hidden flex flex-col items-start justify-start p-8 gap-[32px] border-[1px] border-solid border-text-primary">
              <div className="flex flex-col items-start justify-start gap-[32px]">
                <div className="overflow-hidden flex flex-row items-start justify-start gap-[4px]">
                  <img
                    className="w-5 relative h-[18.9px]"
                    alt=""
                    src="/vector.svg"
                  />
                  <img
                    className="w-5 relative h-[18.9px]"
                    alt=""
                    src="/vector.svg"
                  />
                  <img
                    className="w-5 relative h-[18.9px]"
                    alt=""
                    src="/vector.svg"
                  />
                  <img
                    className="w-5 relative h-[18.9px]"
                    alt=""
                    src="/vector.svg"
                  />
                  <img
                    className="w-5 relative h-[18.9px]"
                    alt=""
                    src="/vector.svg"
                  />
                </div>
                <div className="w-[352px] relative leading-[150%] inline-block">
                  "Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Suspendisse varius enim in eros elementum tristique. Duis
                  cursus, mi quis viverra ornare."
                </div>
              </div>
              <div className="flex flex-row items-center justify-start gap-[16px] text-base">
                <img
                  className="w-14 relative rounded-[50%] h-14 object-cover"
                  alt=""
                  src="/avatar-image@2x.png"
                />
                <div className="flex flex-col items-start justify-start">
                  <div className="relative leading-[150%] font-semibold">
                    Name Surname
                  </div>
                  <div className="relative leading-[150%]">
                    Position, Company name
                  </div>
                </div>
              </div>
            </div>
            <div className="flex-1 overflow-hidden flex flex-col items-start justify-start p-8 gap-[32px] border-[1px] border-solid border-text-primary">
              <div className="flex flex-col items-start justify-start gap-[32px]">
                <div className="overflow-hidden flex flex-row items-start justify-start gap-[4px]">
                  <img
                    className="w-5 relative h-[18.9px]"
                    alt=""
                    src="/vector.svg"
                  />
                  <img
                    className="w-5 relative h-[18.9px]"
                    alt=""
                    src="/vector.svg"
                  />
                  <img
                    className="w-5 relative h-[18.9px]"
                    alt=""
                    src="/vector.svg"
                  />
                  <img
                    className="w-5 relative h-[18.9px]"
                    alt=""
                    src="/vector.svg"
                  />
                  <img
                    className="w-5 relative h-[18.9px]"
                    alt=""
                    src="/vector.svg"
                  />
                </div>
                <div className="w-[352px] relative leading-[150%] inline-block">
                  "Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Suspendisse varius enim in eros elementum tristique. Duis
                  cursus, mi quis viverra ornare."
                </div>
              </div>
              <div className="flex flex-row items-center justify-start gap-[16px] text-base">
                <img
                  className="w-14 relative rounded-[50%] h-14 object-cover"
                  alt=""
                  src="/avatar-image@2x.png"
                />
                <div className="flex flex-col items-start justify-start">
                  <div className="relative leading-[150%] font-semibold">
                    Name Surname
                  </div>
                  <div className="relative leading-[150%]">
                    Position, Company name
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="w-[1440px] bg-background-color-primary overflow-hidden flex flex-col items-center justify-start py-28 px-16 box-border text-center text-29xl">
          <div className="w-[768px] flex flex-col items-center justify-start gap-[80px]">
            <div className="w-[768px] flex flex-col items-center justify-start gap-[24px]">
              <b className="self-stretch relative leading-[120%]">FAQs</b>
              <div className="self-stretch relative text-lg leading-[150%]">
                Find answers to common questions about our live learning
                programs, scheduling, and technical requirements.
              </div>
            </div>
            <div className="self-stretch flex flex-col items-start justify-start gap-[16px] text-left text-lg">
              <div className="self-stretch flex flex-row items-center justify-center py-5 px-6 border-[1px] border-solid border-text-primary">
                <b className="flex-1 relative leading-[150%]">
                  How do I enroll?
                </b>
                <img
                  className="w-8 relative h-8 overflow-hidden shrink-0"
                  alt=""
                  src="/plus.svg"
                />
              </div>
              <div className="self-stretch flex flex-row items-center justify-center py-5 px-6 border-[1px] border-solid border-text-primary">
                <b className="flex-1 relative leading-[150%]">
                  What are the payment options?
                </b>
                <img
                  className="w-8 relative h-8 overflow-hidden shrink-0"
                  alt=""
                  src="/plus.svg"
                />
              </div>
              <div className="self-stretch flex flex-row items-center justify-center py-5 px-6 border-[1px] border-solid border-text-primary">
                <b className="flex-1 relative leading-[150%]">
                  Are there any prerequisites?
                </b>
                <img
                  className="w-8 relative h-8 overflow-hidden shrink-0"
                  alt=""
                  src="/plus.svg"
                />
              </div>
              <div className="self-stretch flex flex-row items-center justify-center py-5 px-6 border-[1px] border-solid border-text-primary">
                <b className="flex-1 relative leading-[150%]">
                  How long are the programs?
                </b>
                <img
                  className="w-8 relative h-8 overflow-hidden shrink-0"
                  alt=""
                  src="/plus.svg"
                />
              </div>
              <div className="self-stretch flex flex-row items-center justify-center py-5 px-6 border-[1px] border-solid border-text-primary">
                <b className="flex-1 relative leading-[150%]">
                  Can I get a refund?
                </b>
                <img
                  className="w-8 relative h-8 overflow-hidden shrink-0"
                  alt=""
                  src="/plus.svg"
                />
              </div>
            </div>
            <div className="w-[560px] flex flex-col items-center justify-start gap-[24px] text-13xl">
              <div className="self-stretch flex flex-col items-center justify-start gap-[16px]">
                <b className="self-stretch relative leading-[130%]">
                  Still have questions?
                </b>
                <div className="self-stretch relative text-lg leading-[150%]">
                  Contact our support team for further assistance.
                </div>
              </div>
              <div className="w-[106px] box-border flex flex-row items-center justify-center py-3 px-6 text-left text-base border-[1px] border-solid border-text-primary">
                <div className="relative leading-[150%]">Contact</div>
              </div>
            </div>
          </div>
        </div>
        <div className="w-[1440px] bg-background-color-primary overflow-hidden flex flex-col items-center justify-start py-20 px-16 box-border gap-[80px] text-sm">
          <div className="self-stretch flex flex-row items-start justify-start gap-[64px]">
            <div className="w-[864px] overflow-hidden shrink-0 flex flex-col items-start justify-start gap-[32px]">
              <img
                className="w-[63px] relative h-[27px] overflow-hidden shrink-0"
                alt=""
                src="/color--dark1.svg"
              />
              <div className="self-stretch flex flex-col items-start justify-start gap-[24px]">
                <div className="self-stretch flex flex-col items-start justify-start gap-[4px]">
                  <div className="self-stretch relative leading-[150%] font-semibold">
                    Address:
                  </div>
                  <div className="self-stretch relative leading-[150%]">
                    Level 1, 12 Sample St, Sydney NSW 2000
                  </div>
                </div>
                <div className="self-stretch flex flex-col items-start justify-start gap-[4px]">
                  <div className="self-stretch relative leading-[150%] font-semibold">
                    Contact:
                  </div>
                  <div className="self-stretch flex flex-col items-start justify-start">
                    <div className="self-stretch relative [text-decoration:underline] leading-[150%]">
                      1800 123 4567
                    </div>
                    <div className="self-stretch relative [text-decoration:underline] leading-[150%]">
                      info@relume.io
                    </div>
                  </div>
                </div>
                <div className="flex flex-row items-start justify-start gap-[12px]">
                  <img
                    className="w-6 relative h-6 overflow-hidden shrink-0"
                    alt=""
                    src="/icon--facebook.svg"
                  />
                  <img
                    className="w-6 relative h-6 overflow-hidden shrink-0"
                    alt=""
                    src="/icon--instagram.svg"
                  />
                  <img
                    className="w-6 relative h-6 overflow-hidden shrink-0"
                    alt=""
                    src="/icon--x.svg"
                  />
                  <img
                    className="w-6 relative h-6 overflow-hidden shrink-0"
                    alt=""
                    src="/icon--linkedin.svg"
                  />
                  <img
                    className="w-6 relative h-6 overflow-hidden shrink-0"
                    alt=""
                    src="/icon--youtube.svg"
                  />
                </div>
              </div>
            </div>
            <div className="flex-1 overflow-hidden flex flex-row items-start justify-start gap-[24px] text-base">
              <div className="flex-1 flex flex-col items-start justify-start gap-[12px]">
                <div className="self-stretch relative leading-[150%] font-semibold">
                  Link One
                </div>
                <div className="self-stretch relative leading-[150%] font-semibold">
                  Link Two
                </div>
                <div className="self-stretch relative leading-[150%] font-semibold">
                  Link Three
                </div>
                <div className="w-[210px] relative leading-[150%] font-semibold inline-block">
                  Link Four
                </div>
                <div className="self-stretch relative leading-[150%] font-semibold">
                  Link Five
                </div>
              </div>
              <div className="flex-1 flex flex-col items-start justify-start gap-[12px]">
                <div className="self-stretch relative leading-[150%] font-semibold">
                  Link Six
                </div>
                <div className="self-stretch relative leading-[150%] font-semibold">
                  Link Seven
                </div>
                <div className="self-stretch relative leading-[150%] font-semibold">
                  Link Eight
                </div>
                <div className="self-stretch relative leading-[150%] font-semibold">
                  Link Nine
                </div>
                <div className="self-stretch relative leading-[150%] font-semibold">
                  Link Ten
                </div>
              </div>
            </div>
          </div>
          <div className="self-stretch flex flex-col items-start justify-start gap-[32px]">
            <div className="self-stretch relative bg-text-primary box-border h-px border-[1px] border-solid border-text-primary" />
            <div className="self-stretch flex flex-row items-start justify-between">
              <div className="relative leading-[150%]">
                © 2024 Relume. All rights reserved.
              </div>
              <div className="flex flex-row items-start justify-start gap-[24px]">
                <div className="relative [text-decoration:underline] leading-[150%]">
                  Privacy Policy
                </div>
                <div className="relative [text-decoration:underline] leading-[150%]">
                  Terms of Service
                </div>
                <div className="relative [text-decoration:underline] leading-[150%]">
                  Cookies Settings
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute top-[0px] left-[1568px] overflow-hidden flex flex-col items-start justify-start">
        <div className="w-[375px] bg-background-color-primary flex flex-col items-center justify-start pt-0 px-0 pb-24 box-border text-lg">
          <div className="self-stretch h-16 overflow-hidden shrink-0 flex flex-row items-center justify-between py-0 pr-3 pl-5 box-border">
            <div className="flex flex-row items-center justify-start">
              <img
                className="w-[63px] relative h-[27px] overflow-hidden shrink-0"
                alt=""
                src="/color--dark.svg"
              />
            </div>
            <div className="w-12 h-12 flex flex-row items-center justify-center">
              <img
                className="w-6 relative h-6 overflow-hidden shrink-0"
                alt=""
                src="/icon--x1.svg"
              />
            </div>
          </div>
          <div className="self-stretch flex flex-col items-start justify-start py-0 px-5">
            <div className="self-stretch overflow-hidden flex flex-col items-start justify-start">
              <div className="self-stretch flex flex-row items-start justify-start py-3 px-0">
                <div className="relative leading-[150%]">Live Learning</div>
              </div>
              <div className="self-stretch flex flex-row items-start justify-start py-3 px-0">
                <div className="relative leading-[150%]">Bite Sized</div>
              </div>
              <div className="self-stretch flex flex-row items-start justify-start py-3 px-0">
                <div className="relative leading-[150%]">Recorded</div>
              </div>
              <div className="self-stretch flex flex-col items-start justify-start">
                <div className="self-stretch flex flex-col items-start justify-start py-2.5 px-0">
                  <div className="self-stretch flex flex-row items-center justify-between">
                    <div className="relative leading-[150%]">LU.ai</div>
                    <img
                      className="w-6 relative h-6 overflow-hidden shrink-0"
                      alt=""
                      src="/chevron-down1.svg"
                    />
                  </div>
                </div>
                <div className="self-stretch flex flex-col items-start justify-start">
                  <div className="self-stretch overflow-hidden flex flex-col items-start justify-start py-3 px-0 gap-[8px]">
                    <div className="w-80 flex flex-row items-center justify-start py-2 px-0 box-border gap-[12px]">
                      <img
                        className="w-6 relative h-6 overflow-hidden shrink-0"
                        alt=""
                        src="/icon--relume4.svg"
                      />
                      <div className="flex-1 flex flex-col items-start justify-start">
                        <div className="self-stretch relative leading-[150%] font-semibold">
                          Page One
                        </div>
                        <div className="w-[284px] relative text-sm leading-[150%] hidden">
                          Learn at your own pace, anytime, anywhere
                        </div>
                      </div>
                    </div>
                    <div className="w-80 flex flex-row items-center justify-start py-2 px-0 box-border gap-[12px]">
                      <img
                        className="w-6 relative h-6 overflow-hidden shrink-0"
                        alt=""
                        src="/icon--relume4.svg"
                      />
                      <div className="flex-1 flex flex-col items-start justify-start">
                        <div className="self-stretch relative leading-[150%] font-semibold">
                          Page Two
                        </div>
                        <div className="w-[284px] relative text-sm leading-[150%] hidden">
                          Connect with industry leaders and experts
                        </div>
                      </div>
                    </div>
                    <div className="w-80 flex flex-row items-center justify-start py-2 px-0 box-border gap-[12px]">
                      <img
                        className="w-6 relative h-6 overflow-hidden shrink-0"
                        alt=""
                        src="/icon--relume4.svg"
                      />
                      <div className="flex-1 flex flex-col items-start justify-start">
                        <div className="self-stretch relative leading-[150%] font-semibold">
                          Page Three
                        </div>
                        <div className="w-[284px] relative text-sm leading-[150%] hidden">
                          Earn LU Coins and unlock exclusive rewards
                        </div>
                      </div>
                    </div>
                    <div className="w-80 flex flex-row items-center justify-start py-2 px-0 box-border gap-[12px]">
                      <img
                        className="w-6 relative h-6 overflow-hidden shrink-0"
                        alt=""
                        src="/icon--relume4.svg"
                      />
                      <div className="flex-1 flex flex-col items-start justify-start">
                        <div className="self-stretch relative leading-[150%] font-semibold">
                          Page Four
                        </div>
                        <div className="w-[284px] relative text-sm leading-[150%] hidden">
                          Stay updated with the latest industry trends
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="self-stretch flex flex-col items-center justify-center pt-4 px-0 pb-0 text-base">
              <div className="self-stretch flex flex-col items-start justify-start gap-[16px]">
                <div className="self-stretch flex flex-row items-center justify-center py-2 px-5 border-[1px] border-solid border-text-primary">
                  <div className="relative leading-[150%]">Join</div>
                </div>
                <div className="self-stretch bg-text-primary flex flex-row items-center justify-center py-2 px-5 text-background-color-primary border-[1px] border-solid border-text-primary">
                  <div className="relative leading-[150%]">Sign Up</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="w-[375px] flex flex-col items-start justify-start py-16 px-5 box-border bg-[url('/layout--4671@3x.png')] bg-cover bg-no-repeat bg-[top] text-background-color-primary">
          <div className="self-stretch flex flex-col items-start justify-start gap-[80px]">
            <div className="self-stretch flex flex-col items-start justify-start">
              <div className="self-stretch flex flex-col items-start justify-start gap-[8px]">
                <div className="self-stretch flex flex-col items-start justify-start gap-[12px]">
                  <div className="self-stretch relative leading-[150%] font-semibold">
                    Engage
                  </div>
                  <div className="self-stretch flex flex-col items-start justify-start gap-[20px] text-17xl">
                    <b className="self-stretch relative leading-[120%]">
                      Interactive Live Learning Programs: Learn, Collaborate,
                      Grow
                    </b>
                    <div className="self-stretch relative text-base leading-[150%]">
                      Experience real-time engagement with our interactive Live
                      Learning Programs. Join our community of learners and
                      enhance your skills in a collaborative environment.
                    </div>
                  </div>
                </div>
                <div className="flex flex-row items-center justify-start pt-4 px-0 pb-0 gap-[24px]">
                  <div className="flex flex-row items-center justify-center py-3 px-6 border-[1px] border-solid border-background-color-primary">
                    <div className="relative leading-[150%]">Learn More</div>
                  </div>
                  <div className="flex flex-row items-center justify-center gap-[8px]">
                    <div className="relative leading-[150%]">Sign Up</div>
                    <img
                      className="w-6 relative h-6 overflow-hidden shrink-0"
                      alt=""
                      src="/icon--chevronright.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="self-stretch flex flex-col items-start justify-end text-lg">
              <div className="self-stretch flex flex-col items-start justify-end py-0 px-6">
                <div className="self-stretch flex flex-col items-start justify-start gap-[32px]">
                  <div className="self-stretch flex flex-col items-start justify-start gap-[12px]">
                    <b className="self-stretch relative leading-[140%]">
                      Learn Together
                    </b>
                    <div className="self-stretch relative text-base leading-[150%]">
                      Connect with industry experts and fellow learners in our
                      live sessions.
                    </div>
                  </div>
                  <div className="self-stretch flex flex-col items-start justify-start gap-[12px]">
                    <b className="self-stretch relative leading-[140%]">
                      Expand Skills
                    </b>
                    <div className="self-stretch relative text-base leading-[150%]">
                      Unlock new opportunities and advance your career with our
                      Live Learning Programs.
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="w-[375px] bg-background-color-primary overflow-hidden flex flex-col items-center justify-start py-16 px-5 box-border gap-[48px] text-center text-13xl">
          <b className="self-stretch relative leading-[120%]">Refer and Earn</b>
          <div className="self-stretch flex flex-col items-center justify-start gap-[48px] text-xl">
            <div className="self-stretch flex flex-col items-center justify-start gap-[16px]">
              <div className="self-stretch flex flex-col items-center justify-start gap-[20px]">
                <img
                  className="w-12 relative h-12 overflow-hidden shrink-0"
                  alt=""
                  src="/icon--relume5.svg"
                />
                <div className="self-stretch flex flex-col items-start justify-start gap-[20px]">
                  <b className="self-stretch relative leading-[140%]">
                    Long heading is what you see here in this feature section
                  </b>
                  <div className="self-stretch relative text-base leading-[150%]">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Suspendisse varius enim in eros elementum tristique. Duis
                    cursus, mi quis viverra ornare, eros dolor interdum nulla.
                  </div>
                </div>
              </div>
              <div className="self-stretch flex flex-col items-center justify-start pt-2 px-0 pb-0 text-left text-base">
                <div className="flex flex-row items-center justify-center gap-[8px]">
                  <div className="relative leading-[150%]">Button</div>
                  <img
                    className="w-6 relative h-6 overflow-hidden shrink-0"
                    alt=""
                    src="/icon--chevronright3.svg"
                  />
                </div>
              </div>
            </div>
            <div className="self-stretch flex flex-col items-center justify-start gap-[16px]">
              <div className="self-stretch flex flex-col items-center justify-start gap-[20px]">
                <img
                  className="w-12 relative h-12 overflow-hidden shrink-0"
                  alt=""
                  src="/icon--relume5.svg"
                />
                <div className="self-stretch flex flex-col items-start justify-start gap-[20px]">
                  <b className="self-stretch relative leading-[140%]">
                    Long heading is what you see here in this feature section
                  </b>
                  <div className="self-stretch relative text-base leading-[150%]">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Suspendisse varius enim in eros elementum tristique. Duis
                    cursus, mi quis viverra ornare, eros dolor interdum nulla.
                  </div>
                </div>
              </div>
              <div className="self-stretch flex flex-col items-center justify-start pt-2 px-0 pb-0 text-left text-base">
                <div className="flex flex-row items-center justify-center gap-[8px]">
                  <div className="relative leading-[150%]">Button</div>
                  <img
                    className="w-6 relative h-6 overflow-hidden shrink-0"
                    alt=""
                    src="/icon--chevronright3.svg"
                  />
                </div>
              </div>
            </div>
            <div className="self-stretch flex flex-col items-center justify-start gap-[16px]">
              <div className="self-stretch flex flex-col items-center justify-start gap-[20px]">
                <img
                  className="w-12 relative h-12 overflow-hidden shrink-0"
                  alt=""
                  src="/icon--relume5.svg"
                />
                <div className="self-stretch flex flex-col items-start justify-start gap-[20px]">
                  <b className="self-stretch relative leading-[140%]">
                    Long heading is what you see here in this feature section
                  </b>
                  <div className="self-stretch relative text-base leading-[150%]">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Suspendisse varius enim in eros elementum tristique. Duis
                    cursus, mi quis viverra ornare, eros dolor interdum nulla.
                  </div>
                </div>
              </div>
              <div className="self-stretch flex flex-col items-center justify-start pt-2 px-0 pb-0 text-left text-base">
                <div className="flex flex-row items-center justify-center gap-[8px]">
                  <div className="relative leading-[150%]">Button</div>
                  <img
                    className="w-6 relative h-6 overflow-hidden shrink-0"
                    alt=""
                    src="/icon--chevronright3.svg"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="w-[375px] bg-background-color-primary overflow-hidden flex flex-col items-center justify-start py-16 px-5 box-border gap-[48px] text-center">
          <div className="self-stretch flex flex-col items-center justify-start gap-[12px]">
            <div className="self-stretch relative leading-[150%] font-semibold">
              Articles
            </div>
            <div className="self-stretch flex flex-col items-center justify-start gap-[20px] text-17xl">
              <b className="self-stretch relative leading-[120%]">
                Explore Our Programs
              </b>
              <div className="self-stretch relative text-base leading-[150%]">
                Discover our live learning programs by subject or skill level.
              </div>
            </div>
          </div>
          <div className="self-stretch flex flex-col items-center justify-start gap-[40px] text-left text-sm">
            <div className="self-stretch flex flex-col items-start justify-start gap-[48px]">
              <div className="self-stretch flex flex-col items-start justify-start border-[1px] border-solid border-text-primary">
                <img
                  className="self-stretch relative max-w-full overflow-hidden h-[221px] shrink-0 object-cover"
                  alt=""
                  src="/placeholder-image@2x.png"
                />
                <div className="self-stretch flex flex-col items-start justify-start py-6 px-5 gap-[24px]">
                  <div className="self-stretch flex flex-col items-start justify-start gap-[8px]">
                    <div className="self-stretch relative leading-[150%] font-semibold">
                      All
                    </div>
                    <b className="self-stretch relative text-xl leading-[140%]">
                      The Power of Coding
                    </b>
                    <div className="self-stretch relative text-base leading-[150%]">
                      Learn coding from industry experts and unlock new
                      opportunities.
                    </div>
                  </div>
                  <div className="self-stretch flex flex-row items-center justify-start gap-[16px]">
                    <img
                      className="w-12 relative h-12 object-cover"
                      alt=""
                      src="/placeholder-image@2x.png"
                    />
                    <div className="flex-1 flex flex-col items-start justify-start">
                      <div className="self-stretch relative leading-[150%] font-semibold">
                        John Doe
                      </div>
                      <div className="self-stretch flex flex-row items-center justify-start gap-[8px]">
                        <div className="relative leading-[150%]">
                          11 Jan 2022
                        </div>
                        <div className="relative text-lg leading-[150%]">•</div>
                        <div className="relative leading-[150%]">
                          5 min read
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="self-stretch flex flex-col items-start justify-start border-[1px] border-solid border-text-primary">
                <img
                  className="self-stretch relative max-w-full overflow-hidden h-[221px] shrink-0 object-cover"
                  alt=""
                  src="/placeholder-image@2x.png"
                />
                <div className="self-stretch flex flex-col items-start justify-start py-6 px-5 gap-[24px]">
                  <div className="self-stretch flex flex-col items-start justify-start gap-[8px]">
                    <div className="self-stretch relative leading-[150%] font-semibold">
                      Coding
                    </div>
                    <b className="self-stretch relative text-xl leading-[140%]">
                      The Future of AI
                    </b>
                    <div className="self-stretch relative text-base leading-[150%]">
                      Explore the world of artificial intelligence and its
                      applications.
                    </div>
                  </div>
                  <div className="self-stretch flex flex-row items-center justify-start gap-[16px]">
                    <img
                      className="w-12 relative h-12 object-cover"
                      alt=""
                      src="/placeholder-image@2x.png"
                    />
                    <div className="flex-1 flex flex-col items-start justify-start">
                      <div className="self-stretch relative leading-[150%] font-semibold">
                        Jane Smith
                      </div>
                      <div className="self-stretch flex flex-row items-center justify-start gap-[8px]">
                        <div className="relative leading-[150%]">
                          11 Jan 2022
                        </div>
                        <div className="relative text-lg leading-[150%]">•</div>
                        <div className="relative leading-[150%]">
                          7 min read
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="self-stretch flex flex-col items-start justify-start border-[1px] border-solid border-text-primary">
                <img
                  className="self-stretch relative max-w-full overflow-hidden h-[221px] shrink-0 object-cover"
                  alt=""
                  src="/placeholder-image@2x.png"
                />
                <div className="self-stretch flex flex-col items-start justify-start py-6 px-5 gap-[24px]">
                  <div className="self-stretch flex flex-col items-start justify-start gap-[8px]">
                    <div className="self-stretch relative leading-[150%] font-semibold">
                      AI
                    </div>
                    <b className="self-stretch relative text-xl leading-[140%]">
                      Master Data Analytics
                    </b>
                    <div className="self-stretch relative text-base leading-[150%]">
                      Gain insights from data and make informed business
                      decisions.
                    </div>
                  </div>
                  <div className="self-stretch flex flex-row items-center justify-start gap-[16px]">
                    <img
                      className="w-12 relative h-12 object-cover"
                      alt=""
                      src="/placeholder-image@2x.png"
                    />
                    <div className="flex-1 flex flex-col items-start justify-start">
                      <div className="self-stretch relative leading-[150%] font-semibold">
                        David Johnson
                      </div>
                      <div className="self-stretch flex flex-row items-center justify-start gap-[8px]">
                        <div className="relative leading-[150%]">
                          11 Jan 2022
                        </div>
                        <div className="relative text-lg leading-[150%]">•</div>
                        <div className="relative leading-[150%]">
                          6 min read
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="w-[106px] box-border flex flex-row items-center justify-center py-3 px-6 text-base border-[1px] border-solid border-text-primary">
              <div className="relative leading-[150%]">View All</div>
            </div>
          </div>
        </div>
        <div className="w-[375px] bg-background-color-primary overflow-hidden flex flex-col items-start justify-start py-16 px-5 box-border gap-[48px]">
          <div className="self-stretch flex flex-col items-start justify-start gap-[24px]">
            <div className="self-stretch flex flex-col items-start justify-start gap-[12px]">
              <div className="relative leading-[150%] font-semibold">
                Tagline
              </div>
              <div className="self-stretch flex flex-col items-center justify-start gap-[12px] text-17xl">
                <b className="self-stretch relative leading-[120%]">Products</b>
                <div className="self-stretch relative text-base leading-[150%]">{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</div>
              </div>
            </div>
            <div className="w-[106px] box-border hidden flex-row items-center justify-center py-3 px-6 border-[1px] border-solid border-text-primary">
              <div className="relative leading-[150%]">View all</div>
            </div>
          </div>
          <div className="self-stretch flex flex-col items-start justify-start gap-[48px] text-lg">
            <div className="w-[1312px] flex flex-col items-start justify-start">
              <div className="self-stretch flex flex-row items-start justify-start gap-[24px]">
                <div className="w-[300px] flex flex-col items-start justify-start gap-[16px]">
                  <img
                    className="self-stretch relative max-w-full overflow-hidden h-[360px] shrink-0 object-cover"
                    alt=""
                    src="/placeholder-image@2x.png"
                  />
                  <div className="self-stretch flex flex-row items-start justify-start gap-[16px]">
                    <div className="flex-1 flex flex-col items-start justify-start">
                      <div className="self-stretch relative leading-[150%] font-semibold">
                        Product name
                      </div>
                      <div className="self-stretch relative text-sm leading-[150%]">
                        Variant
                      </div>
                    </div>
                    <div className="relative text-xl leading-[150%] font-semibold">
                      $55
                    </div>
                  </div>
                  <div className="self-stretch flex flex-row items-center justify-center py-2 px-5 text-base border-[1px] border-solid border-text-primary">
                    <div className="relative leading-[150%]">Add to cart</div>
                  </div>
                </div>
                <div className="w-[300px] flex flex-col items-start justify-start gap-[16px]">
                  <img
                    className="self-stretch relative max-w-full overflow-hidden h-[360px] shrink-0 object-cover"
                    alt=""
                    src="/placeholder-image@2x.png"
                  />
                  <div className="self-stretch flex flex-row items-start justify-start gap-[16px]">
                    <div className="flex-1 flex flex-col items-start justify-start">
                      <div className="self-stretch relative leading-[150%] font-semibold">
                        Product name
                      </div>
                      <div className="self-stretch relative text-sm leading-[150%]">
                        Variant
                      </div>
                    </div>
                    <div className="relative text-xl leading-[150%] font-semibold">
                      $55
                    </div>
                  </div>
                  <div className="self-stretch flex flex-row items-center justify-center py-2 px-5 text-base border-[1px] border-solid border-text-primary">
                    <div className="relative leading-[150%]">Add to cart</div>
                  </div>
                </div>
                <div className="w-[300px] flex flex-col items-start justify-start gap-[16px]">
                  <img
                    className="self-stretch relative max-w-full overflow-hidden h-[360px] shrink-0 object-cover"
                    alt=""
                    src="/placeholder-image@2x.png"
                  />
                  <div className="self-stretch flex flex-row items-start justify-start gap-[16px]">
                    <div className="flex-1 flex flex-col items-start justify-start">
                      <div className="self-stretch relative leading-[150%] font-semibold">
                        Product name
                      </div>
                      <div className="self-stretch relative text-sm leading-[150%]">
                        Variant
                      </div>
                    </div>
                    <div className="relative text-xl leading-[150%] font-semibold">
                      $55
                    </div>
                  </div>
                  <div className="self-stretch flex flex-row items-center justify-center py-2 px-5 text-base border-[1px] border-solid border-text-primary">
                    <div className="relative leading-[150%]">Add to cart</div>
                  </div>
                </div>
                <div className="w-[300px] flex flex-col items-start justify-start gap-[16px]">
                  <img
                    className="self-stretch relative max-w-full overflow-hidden h-[360px] shrink-0 object-cover"
                    alt=""
                    src="/placeholder-image@2x.png"
                  />
                  <div className="self-stretch flex flex-row items-start justify-start gap-[16px]">
                    <div className="flex-1 flex flex-col items-start justify-start">
                      <div className="self-stretch relative leading-[150%] font-semibold">
                        Product name
                      </div>
                      <div className="self-stretch relative text-sm leading-[150%]">
                        Variant
                      </div>
                    </div>
                    <div className="relative text-xl leading-[150%] font-semibold">
                      $55
                    </div>
                  </div>
                  <div className="self-stretch flex flex-row items-center justify-center py-2 px-5 text-base border-[1px] border-solid border-text-primary">
                    <div className="relative leading-[150%]">Add to cart</div>
                  </div>
                </div>
                <div className="w-[300px] flex flex-col items-start justify-start gap-[16px]">
                  <img
                    className="self-stretch relative max-w-full overflow-hidden h-[360px] shrink-0 object-cover"
                    alt=""
                    src="/placeholder-image@2x.png"
                  />
                  <div className="self-stretch flex flex-row items-start justify-start gap-[16px]">
                    <div className="flex-1 flex flex-col items-start justify-start">
                      <div className="self-stretch relative leading-[150%] font-semibold">
                        Product name
                      </div>
                      <div className="self-stretch relative text-sm leading-[150%]">
                        Variant
                      </div>
                    </div>
                    <div className="relative text-xl leading-[150%] font-semibold">
                      $55
                    </div>
                  </div>
                  <div className="self-stretch flex flex-row items-center justify-center py-2 px-5 text-base border-[1px] border-solid border-text-primary">
                    <div className="relative leading-[150%]">Add to cart</div>
                  </div>
                </div>
              </div>
            </div>
            <div className="self-stretch flex flex-row items-center justify-between">
              <div className="flex flex-row items-start justify-start gap-[8px]">
                <div className="w-2 relative rounded-[50%] bg-text-primary h-2" />
                <div className="w-2 relative rounded-[50%] bg-color-neutral-neutral-lighter h-2" />
                <div className="w-2 relative rounded-[50%] bg-color-neutral-neutral-lighter h-2" />
                <div className="w-2 relative rounded-[50%] bg-color-neutral-neutral-lighter h-2" />
                <div className="w-2 relative rounded-[50%] bg-color-neutral-neutral-lighter h-2" />
              </div>
              <div className="flex flex-row items-start justify-start gap-[15px]">
                <div className="rounded-31xl flex flex-row items-center justify-center p-3 border-[1px] border-solid border-text-primary">
                  <img
                    className="w-6 relative h-6 overflow-hidden shrink-0"
                    alt=""
                    src="/icon2.svg"
                  />
                </div>
                <div className="rounded-31xl flex flex-row items-center justify-center p-3 border-[1px] border-solid border-text-primary">
                  <img
                    className="w-6 relative h-6 overflow-hidden shrink-0"
                    alt=""
                    src="/icon3.svg"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="w-[375px] bg-background-color-primary overflow-hidden flex flex-col items-center justify-start py-16 px-5 box-border gap-[48px] text-center text-17xl">
          <div className="self-stretch flex flex-col items-center justify-start gap-[20px]">
            <b className="self-stretch relative leading-[120%]">
              Customer testimonials
            </b>
            <div className="self-stretch relative text-base leading-[150%]">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            </div>
          </div>
          <div className="self-stretch flex flex-col items-start justify-start gap-[32px] text-left text-base">
            <div className="self-stretch overflow-hidden flex flex-col items-start justify-start p-6 gap-[20px] border-[1px] border-solid border-text-primary">
              <div className="flex flex-col items-start justify-start gap-[24px]">
                <div className="overflow-hidden flex flex-row items-start justify-start gap-[4px]">
                  <img
                    className="w-5 relative h-[18.9px]"
                    alt=""
                    src="/vector1.svg"
                  />
                  <img
                    className="w-5 relative h-[18.9px]"
                    alt=""
                    src="/vector1.svg"
                  />
                  <img
                    className="w-5 relative h-[18.9px]"
                    alt=""
                    src="/vector1.svg"
                  />
                  <img
                    className="w-5 relative h-[18.9px]"
                    alt=""
                    src="/vector1.svg"
                  />
                  <img
                    className="w-5 relative h-[18.9px]"
                    alt=""
                    src="/vector1.svg"
                  />
                </div>
                <div className="w-[287px] relative leading-[150%] inline-block">
                  "Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Suspendisse varius enim in eros elementum tristique. Duis
                  cursus, mi quis viverra ornare."
                </div>
              </div>
              <div className="self-stretch flex flex-col items-start justify-center gap-[16px]">
                <img
                  className="w-14 relative rounded-[50%] h-14 object-cover"
                  alt=""
                  src="/avatar-image@2x.png"
                />
                <div className="flex flex-col items-start justify-start">
                  <div className="relative leading-[150%] font-semibold">
                    Name Surname
                  </div>
                  <div className="relative leading-[150%]">
                    Position, Company name
                  </div>
                </div>
              </div>
            </div>
            <div className="self-stretch overflow-hidden flex flex-col items-start justify-start p-6 gap-[20px] border-[1px] border-solid border-text-primary">
              <div className="flex flex-col items-start justify-start gap-[24px]">
                <div className="overflow-hidden flex flex-row items-start justify-start gap-[4px]">
                  <img
                    className="w-5 relative h-[18.9px]"
                    alt=""
                    src="/vector2.svg"
                  />
                  <img
                    className="w-5 relative h-[18.9px]"
                    alt=""
                    src="/vector2.svg"
                  />
                  <img
                    className="w-5 relative h-[18.9px]"
                    alt=""
                    src="/vector2.svg"
                  />
                  <img
                    className="w-5 relative h-[18.9px]"
                    alt=""
                    src="/vector2.svg"
                  />
                  <img
                    className="w-5 relative h-[18.9px]"
                    alt=""
                    src="/vector2.svg"
                  />
                </div>
                <div className="w-[287px] relative leading-[150%] inline-block">
                  "Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Suspendisse varius enim in eros elementum tristique. Duis
                  cursus, mi quis viverra ornare."
                </div>
              </div>
              <div className="self-stretch flex flex-col items-start justify-center gap-[16px]">
                <img
                  className="w-14 relative rounded-[50%] h-14 object-cover"
                  alt=""
                  src="/avatar-image@2x.png"
                />
                <div className="flex flex-col items-start justify-start">
                  <div className="relative leading-[150%] font-semibold">
                    Name Surname
                  </div>
                  <div className="relative leading-[150%]">
                    Position, Company name
                  </div>
                </div>
              </div>
            </div>
            <div className="self-stretch overflow-hidden flex flex-col items-start justify-start p-6 gap-[20px] border-[1px] border-solid border-text-primary">
              <div className="flex flex-col items-start justify-start gap-[24px]">
                <div className="overflow-hidden flex flex-row items-start justify-start gap-[4px]">
                  <img
                    className="w-5 relative h-[18.9px]"
                    alt=""
                    src="/vector3.svg"
                  />
                  <img
                    className="w-5 relative h-[18.9px]"
                    alt=""
                    src="/vector3.svg"
                  />
                  <img
                    className="w-5 relative h-[18.9px]"
                    alt=""
                    src="/vector3.svg"
                  />
                  <img
                    className="w-5 relative h-[18.9px]"
                    alt=""
                    src="/vector3.svg"
                  />
                  <img
                    className="w-5 relative h-[18.9px]"
                    alt=""
                    src="/vector3.svg"
                  />
                </div>
                <div className="w-[287px] relative leading-[150%] inline-block">
                  "Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Suspendisse varius enim in eros elementum tristique. Duis
                  cursus, mi quis viverra ornare."
                </div>
              </div>
              <div className="self-stretch flex flex-col items-start justify-center gap-[16px]">
                <img
                  className="w-14 relative rounded-[50%] h-14 object-cover"
                  alt=""
                  src="/avatar-image@2x.png"
                />
                <div className="flex flex-col items-start justify-start">
                  <div className="relative leading-[150%] font-semibold">
                    Name Surname
                  </div>
                  <div className="relative leading-[150%]">
                    Position, Company name
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="w-[375px] bg-background-color-primary overflow-hidden flex flex-col items-center justify-start py-16 px-5 box-border text-center text-17xl">
          <div className="self-stretch flex flex-col items-center justify-start gap-[48px]">
            <div className="self-stretch flex flex-col items-center justify-start gap-[20px]">
              <b className="self-stretch relative leading-[120%]">FAQs</b>
              <div className="self-stretch relative text-base leading-[150%]">
                Find answers to common questions about our live learning
                programs, scheduling, and technical requirements.
              </div>
            </div>
            <div className="self-stretch flex flex-col items-start justify-start gap-[16px] text-left text-base">
              <div className="self-stretch flex flex-row items-center justify-start py-4 px-5 border-[1px] border-solid border-text-primary">
                <b className="flex-1 relative leading-[150%]">
                  How do I enroll?
                </b>
                <img
                  className="w-8 relative h-8 overflow-hidden shrink-0"
                  alt=""
                  src="/plus1.svg"
                />
              </div>
              <div className="self-stretch flex flex-row items-center justify-start py-4 px-5 border-[1px] border-solid border-text-primary">
                <b className="flex-1 relative leading-[150%]">
                  What are the payment options?
                </b>
                <img
                  className="w-8 relative h-8 overflow-hidden shrink-0"
                  alt=""
                  src="/plus1.svg"
                />
              </div>
              <div className="self-stretch flex flex-row items-center justify-start py-4 px-5 border-[1px] border-solid border-text-primary">
                <b className="flex-1 relative leading-[150%]">
                  Are there any prerequisites?
                </b>
                <img
                  className="w-8 relative h-8 overflow-hidden shrink-0"
                  alt=""
                  src="/plus1.svg"
                />
              </div>
              <div className="self-stretch flex flex-row items-center justify-start py-4 px-5 border-[1px] border-solid border-text-primary">
                <b className="flex-1 relative leading-[150%]">
                  How long are the programs?
                </b>
                <img
                  className="w-8 relative h-8 overflow-hidden shrink-0"
                  alt=""
                  src="/plus1.svg"
                />
              </div>
              <div className="self-stretch flex flex-row items-center justify-start py-4 px-5 border-[1px] border-solid border-text-primary">
                <b className="flex-1 relative leading-[150%]">
                  Can I get a refund?
                </b>
                <img
                  className="w-8 relative h-8 overflow-hidden shrink-0"
                  alt=""
                  src="/plus1.svg"
                />
              </div>
            </div>
            <div className="self-stretch flex flex-col items-center justify-start gap-[24px] text-5xl">
              <div className="self-stretch flex flex-col items-center justify-start gap-[16px]">
                <b className="self-stretch relative leading-[140%]">
                  Still have questions?
                </b>
                <div className="self-stretch relative text-base leading-[150%]">
                  Contact our support team for further assistance.
                </div>
              </div>
              <div className="w-[106px] box-border flex flex-row items-center justify-center py-3 px-6 text-left text-base border-[1px] border-solid border-text-primary">
                <div className="relative leading-[150%]">Contact</div>
              </div>
            </div>
          </div>
        </div>
        <div className="w-[375px] bg-background-color-primary overflow-hidden flex flex-col items-start justify-start py-12 px-5 box-border gap-[48px] text-sm">
          <div className="self-stretch flex flex-col items-start justify-start gap-[48px]">
            <div className="self-stretch overflow-hidden flex flex-col items-start justify-start gap-[24px]">
              <img
                className="w-[63px] relative h-[27px] overflow-hidden shrink-0"
                alt=""
                src="/color--dark2.svg"
              />
              <div className="self-stretch flex flex-col items-start justify-start gap-[24px]">
                <div className="self-stretch flex flex-col items-start justify-start gap-[4px]">
                  <div className="self-stretch relative leading-[150%] font-semibold">
                    Address:
                  </div>
                  <div className="self-stretch relative leading-[150%]">
                    Level 1, 12 Sample St, Sydney NSW 2000
                  </div>
                </div>
                <div className="self-stretch flex flex-col items-start justify-start gap-[4px]">
                  <div className="self-stretch relative leading-[150%] font-semibold">
                    Contact:
                  </div>
                  <div className="self-stretch flex flex-col items-start justify-start">
                    <div className="self-stretch relative [text-decoration:underline] leading-[150%]">
                      1800 123 4567
                    </div>
                    <div className="self-stretch relative [text-decoration:underline] leading-[150%]">
                      info@relume.io
                    </div>
                  </div>
                </div>
                <div className="flex flex-row items-start justify-start gap-[12px]">
                  <img
                    className="w-6 relative h-6 overflow-hidden shrink-0"
                    alt=""
                    src="/icon--facebook1.svg"
                  />
                  <img
                    className="w-6 relative h-6 overflow-hidden shrink-0"
                    alt=""
                    src="/icon--instagram1.svg"
                  />
                  <img
                    className="w-6 relative h-6 overflow-hidden shrink-0"
                    alt=""
                    src="/icon--x2.svg"
                  />
                  <img
                    className="w-6 relative h-6 overflow-hidden shrink-0"
                    alt=""
                    src="/icon--linkedin1.svg"
                  />
                  <img
                    className="w-6 relative h-6 overflow-hidden shrink-0"
                    alt=""
                    src="/icon--youtube1.svg"
                  />
                </div>
              </div>
            </div>
            <div className="self-stretch overflow-hidden flex flex-col items-start justify-start gap-[40px]">
              <div className="self-stretch flex flex-col items-start justify-start gap-[12px]">
                <div className="self-stretch relative leading-[150%] font-semibold">
                  Link One
                </div>
                <div className="self-stretch relative leading-[150%] font-semibold">
                  Link Two
                </div>
                <div className="self-stretch relative leading-[150%] font-semibold">
                  Link Three
                </div>
                <div className="w-[365px] relative leading-[150%] font-semibold inline-block">
                  Link Four
                </div>
                <div className="self-stretch relative leading-[150%] font-semibold">
                  Link Five
                </div>
              </div>
              <div className="self-stretch flex flex-col items-start justify-start gap-[12px]">
                <div className="self-stretch relative leading-[150%] font-semibold">
                  Link Six
                </div>
                <div className="self-stretch relative leading-[150%] font-semibold">
                  Link Seven
                </div>
                <div className="self-stretch relative leading-[150%] font-semibold">
                  Link Eight
                </div>
                <div className="self-stretch relative leading-[150%] font-semibold">
                  Link Nine
                </div>
                <div className="self-stretch relative leading-[150%] font-semibold">
                  Link Ten
                </div>
              </div>
            </div>
          </div>
          <div className="self-stretch flex flex-col items-start justify-start gap-[24px]">
            <div className="self-stretch relative bg-text-primary box-border h-px border-[1px] border-solid border-text-primary" />
            <div className="self-stretch flex flex-col items-start justify-start pt-0 px-0 pb-4 gap-[32px]">
              <div className="flex flex-col items-start justify-start gap-[16px]">
                <div className="relative [text-decoration:underline] leading-[150%]">
                  Privacy Policy
                </div>
                <div className="relative [text-decoration:underline] leading-[150%]">
                  Terms of Service
                </div>
                <div className="relative [text-decoration:underline] leading-[150%]">
                  Cookies Settings
                </div>
              </div>
              <div className="relative leading-[150%]">
                © 2024 Relume. All rights reserved.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LiveLearningPrograms;
